package com.freeapps.apkbuilder;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    WebView w;
    ValueCallback<Uri[]> cb;
    Uri lastApk;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        getWindow().setStatusBarColor(0xFF070D21);
        getWindow().setNavigationBarColor(0xFF070D21);
        w.setBackgroundColor(0xFF070D21);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        w.addJavascriptInterface(new Bridge(), "AKA");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Cannot open link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> c, FileChooserParams p) {
                if (cb != null) cb.onReceiveValue(null);
                cb = c;
                try {
                    startActivityForResult(p.createIntent(), 1);
                } catch (Exception e) {
                    cb = null;
                    return false;
                }
                return true;
            }
        });
        w.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface
        public void download(final String url, final String token, final String unused) {
            if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2));
                done(false, "Allow storage permission, then tap Download again");
                return;
            }
            new Thread(() -> fetchApk(url, token)).start();
        }

        @JavascriptInterface
        public void install() {
            runOnUiThread(() -> doInstall());
        }
    }

    void fetchApk(String url, String token) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/vnd.github+json");
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            if (loc == null) throw new Exception("GitHub replied " + code);
            HttpURLConnection d = (HttpURLConnection) new URL(loc).openConnection();
            ZipInputStream z = new ZipInputStream(new BufferedInputStream(d.getInputStream()));
            ZipEntry e;
            String saved = null;
            while ((e = z.getNextEntry()) != null) {
                if (e.getName().toLowerCase().endsWith(".apk")) {
                    String name = new File(e.getName()).getName();
                    lastApk = save(z, name);
                    saved = name;
                    break;
                }
            }
            z.close();
            if (saved == null) throw new Exception("No .apk file inside the download");
            done(true, "Saved to Downloads: " + saved);
        } catch (Exception ex) {
            done(false, String.valueOf(ex.getMessage()));
        }
    }

    Uri save(InputStream in, String name) throws IOException {
        OutputStream out;
        Uri u = null;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            out = getContentResolver().openOutputStream(u);
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            dir.mkdirs();
            out = new FileOutputStream(new File(dir, name));
        }
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.close();
        return u;
    }

    void done(boolean ok, String msg) {
        final String js = "onDl(" + ok + "," + JSONObject.quote(msg) + ")";
        runOnUiThread(() -> w.evaluateJavascript(js, null));
    }

    void doInstall() {
        if (lastApk == null) {
            Toast.makeText(this, "Open your Downloads folder and tap the APK", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(lastApk, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Open your Downloads folder and tap the APK", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int q, int r, Intent d) {
        if (q == 1 && cb != null) {
            cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r, d));
            cb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
