package com.example.bigbig

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvShizukuStatus: TextView
    private lateinit var btnConnectShizuku: Button
    private lateinit var tvActivePreset: TextView
    private lateinit var layoutPresetOptions: LinearLayout
    private lateinit var tvPresetHeader: TextView

    private val shizukuPackage = "moe.shizuku.privileged.api"
    private val requestCodeShizuku = 1001
    private var isAccordionOpen = true

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { updateShizukuStatus() }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { updateShizukuStatus() }
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == requestCodeShizuku) {
                runOnUiThread {
                    if (grantResult == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Shizuku permission granted!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Shizuku permission denied.", Toast.LENGTH_SHORT).show()
                    }
                    updateShizukuStatus()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)
        btnConnectShizuku = findViewById(R.id.btnConnectShizuku)
        tvActivePreset = findViewById(R.id.tvActivePreset)
        layoutPresetOptions = findViewById(R.id.layoutPresetOptions)
        tvPresetHeader = findViewById(R.id.tvPresetHeader)

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        showCreditDialog()
        setupListeners()
        updateShizukuStatus()
    }

    override fun onResume() {
        super.onResume()
        updateShizukuStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }

    private fun showCreditDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_credit, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        dialogView.findViewById<Button>(R.id.btnCloseCredit).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.btnShowCredits).setOnClickListener {
            showCreditDialog()
        }

        tvPresetHeader.setOnClickListener {
            isAccordionOpen = !isAccordionOpen
            layoutPresetOptions.visibility = if (isAccordionOpen) View.VISIBLE else View.GONE
            tvPresetHeader.text = if (isAccordionOpen) "View Mode Preset  ▼" else "View Mode Preset  ▶"
        }

        findViewById<Button>(R.id.btnPreset1).setOnClickListener {
            applyPresetState("Preset 1 (2X)")
        }

        findViewById<Button>(R.id.btnPreset2).setOnClickListener {
            applyPresetState("Preset 2 (3X)")
        }

        findViewById<Button>(R.id.btnResetDefault).setOnClickListener {
            applyPresetState("Default")
        }

        findViewById<Button>(R.id.btnRefreshShizuku).setOnClickListener {
            updateShizukuStatus()
            Toast.makeText(this, "Shizuku status refreshed", Toast.LENGTH_SHORT).show()
        }

        btnConnectShizuku.setOnClickListener {
            handleConnectAction()
        }
    }

    private fun applyPresetState(modeLabel: String) {
        if (!isShizukuReady()) {
            Toast.makeText(this, "Please connect Shizuku first", Toast.LENGTH_SHORT).show()
            return
        }
        tvActivePreset.text = "Active Mode: $modeLabel"
        tvActivePreset.setTextColor(Color.parseColor("#00F5D4"))
        Toast.makeText(this, "UI state set to $modeLabel (no game files altered)", Toast.LENGTH_SHORT).show()
    }

    private fun isShizukuInstalled(): Boolean {
        return try {
            packageManager.getPackageInfo(shizukuPackage, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun isShizukuReady(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    private fun updateShizukuStatus() {
        val installed = isShizukuInstalled()
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }

        when {
            !installed && !binderAlive -> {
                tvShizukuStatus.text = "Shizuku: Not Installed"
                tvShizukuStatus.setTextColor(Color.parseColor("#FF4D6D"))
                btnConnectShizuku.text = "OPEN SHIZUKU"
            }
            !binderAlive -> {
                tvShizukuStatus.text = "Shizuku: Installed (Service Stopped)"
                tvShizukuStatus.setTextColor(Color.parseColor("#FFB703"))
                btnConnectShizuku.text = "OPEN SHIZUKU"
            }
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                tvShizukuStatus.text = "Shizuku: Running (Permission Needed)"
                tvShizukuStatus.setTextColor(Color.parseColor("#FFB703"))
                btnConnectShizuku.text = "GRANT PERMISSION"
            }
            else -> {
                tvShizukuStatus.text = "Shizuku: Connected (v${Shizuku.getVersion()})"
                tvShizukuStatus.setTextColor(Color.parseColor("#00F5D4"))
                btnConnectShizuku.text = "CONNECTED"
            }
        }
    }

    private fun handleConnectAction() {
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }

        if (binderAlive) {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    Toast.makeText(
                        this,
                        "Enable BigBig inside Shizuku -> Authorized applications",
                        Toast.LENGTH_LONG
                    ).show()
                }
                Shizuku.requestPermission(requestCodeShizuku)
            } else {
                Toast.makeText(this, "Already connected to Shizuku!", Toast.LENGTH_SHORT).show()
            }
            return
        }

        val launchIntent: Intent? = packageManager.getLaunchIntentForPackage(shizukuPackage)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Shizuku app not found on device", Toast.LENGTH_SHORT).show()
        }
    }
}
