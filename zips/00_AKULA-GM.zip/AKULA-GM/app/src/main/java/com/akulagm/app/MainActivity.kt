package com.akulagm.app

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.akulagm.app.data.Game
import com.akulagm.app.data.GameRepository
import com.akulagm.app.overlay.OverlayService
import com.akulagm.app.shizuku.ShizukuManager
import com.akulagm.app.ui.AppPickerDialog
import com.akulagm.app.ui.GameAdapter
import com.akulagm.app.ui.Ui
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import rikka.shizuku.Shizuku
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var repository: GameRepository
    private lateinit var adapter: GameAdapter
    private val handler = Handler(Looper.getMainLooper())

    private val games = mutableListOf<Game>()
    private var selectedGame: Game? = null
    private var pendingGame: Game? = null
    private var noticeShown = false

    private lateinit var tvGameName: TextView
    private lateinit var tvGamePackage: TextView
    private lateinit var tvGameInstall: TextView
    private lateinit var tvPkgValue: TextView
    private lateinit var tvVersionValue: TextView
    private lateinit var tvSizeValue: TextView
    private lateinit var tvStatusValue: TextView
    private lateinit var tvInfoHint: TextView
    private lateinit var tvShizukuState: TextView
    private lateinit var tvShizukuDot: TextView
    private lateinit var ivGameIcon: ImageView
    private lateinit var btnLaunch: MaterialButton
    private lateinit var btnConnect: MaterialButton

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            val game = pendingGame
            pendingGame = null
            if (Settings.canDrawOverlays(this)) {
                if (game != null) doLaunch(game, withOverlay = true)
            } else {
                toast("Overlay denied — launching game without the bubble")
                if (game != null) doLaunch(game, withOverlay = false)
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread {
                    updateShizukuUi()
                    if (grantResult == PackageManager.PERMISSION_GRANTED) {
                        toast("Shizuku connected")
                    }
                }
            }
        }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { updateShizukuUi() }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { updateShizukuUi() }
    }

    private val hideNoticeRunnable = Runnable { hideNotice() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        applyInsets()

        repository = GameRepository(this)
        setupUi()
        registerShizukuListeners()

        games.clear()
        games.addAll(repository.load())
        adapter.submit(games, repository.selectedPackage())

        val initial = games.firstOrNull { it.packageName == repository.selectedPackage() }
            ?: games.firstOrNull()
        if (initial != null) selectGame(initial) else clearInfo()

        AppCloseBus.listener = {
            runCatching { finishAndRemoveTask() }
            finish()
        }

        requestNotificationPermissionIfNeeded()
    }

    private fun applyInsets() {
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
    }

    private fun setupUi() {
        tvGameName = findViewById(R.id.tvGameName)
        tvGamePackage = findViewById(R.id.tvGamePackage)
        tvGameInstall = findViewById(R.id.tvGameInstall)
        tvPkgValue = findViewById(R.id.tvPkgValue)
        tvVersionValue = findViewById(R.id.tvVersionValue)
        tvSizeValue = findViewById(R.id.tvSizeValue)
        tvStatusValue = findViewById(R.id.tvStatusValue)
        tvInfoHint = findViewById(R.id.tvInfoHint)
        tvShizukuState = findViewById(R.id.tvShizukuState)
        tvShizukuDot = findViewById(R.id.tvShizukuDot)
        ivGameIcon = findViewById(R.id.ivGameIcon)
        btnLaunch = findViewById(R.id.btnLaunch)
        btnConnect = findViewById(R.id.btnConnect)

        adapter = GameAdapter(this, ::selectGame, ::confirmRemoveGame)
        findViewById<RecyclerView>(R.id.rvGames).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setHasFixedSize(false)
        }

        findViewById<View>(R.id.creditButton).setOnClickListener { showCredits() }
        findViewById<View>(R.id.btnAddGame).setOnClickListener { showAppPicker() }
        findViewById<View>(R.id.btnLaunch).setOnClickListener { launchSelected() }
        findViewById<View>(R.id.btnConnect).setOnClickListener { connectShizuku() }
        findViewById<View>(R.id.btnNoticeConnect).setOnClickListener { connectShizuku() }
    }

    private fun registerShizukuListeners() {
        runCatching { Shizuku.addBinderReceivedListenerSticky(binderReceivedListener) }
        runCatching { Shizuku.addBinderDeadListener(binderDeadListener) }
        runCatching { Shizuku.addRequestPermissionResultListener(permissionListener) }
    }

    override fun onResume() {
        super.onResume()
        updateShizukuUi()
        selectedGame?.let { refreshSelection(it) }
    }

    private fun refreshSelection(game: Game) {
        if (selectedGame?.packageName == game.packageName) {
            selectGame(game)
        }
    }

    private fun selectGame(game: Game) {
        selectedGame = game
        repository.setSelected(game.packageName)
        adapter.setSelected(game.packageName)

        tvGameName.text = game.name
        tvGamePackage.text = game.packageName
        tvPkgValue.text = game.packageName

        val icon = runCatching { packageManager.getApplicationIcon(game.packageName) }
            .getOrElse {
                ContextCompat.getDrawable(this, R.drawable.ic_game_placeholder)
            }
        ivGameIcon.setImageDrawable(icon)

        val packageInfo = runCatching {
            packageManager.getPackageInfo(game.packageName, 0)
        }.getOrNull()

        if (packageInfo != null) {
            tvGameInstall.text = "INSTALLED"
            tvGameInstall.setTextColor(ContextCompat.getColor(this, R.color.green_500))
            tvVersionValue.text = packageInfo.versionName ?: "—"
            tvStatusValue.text = "Ready to launch"
            val source = packageInfo.applicationInfo?.sourceDir
            tvSizeValue.text = if (source != null) formatSize(File(source).length()) else "—"
            tvInfoHint.text =
                "${game.name} is installed. Launch it, then tap the floating AKULA bubble to boost while you play."
            btnLaunch.isEnabled = true
        } else {
            tvGameInstall.text = "NOT INSTALLED"
            tvGameInstall.setTextColor(ContextCompat.getColor(this, R.color.red_500))
            tvVersionValue.text = "—"
            tvSizeValue.text = "—"
            tvStatusValue.text = "Install this package to launch"
            tvInfoHint.text =
                "${game.name} is not installed on this device. Install ${game.packageName}, or add your installed copy."
            btnLaunch.isEnabled = false
        }
    }

    private fun clearInfo() {
        selectedGame = null
        tvGameName.text = "No game selected"
        tvGamePackage.text = "—"
        tvPkgValue.text = "—"
        tvVersionValue.text = "—"
        tvSizeValue.text = "—"
        tvStatusValue.text = "Add a game to begin"
        tvGameInstall.text = "—"
        tvGameInstall.setTextColor(ContextCompat.getColor(this, R.color.text_dim))
        tvInfoHint.text = "Add a game from the library, launch it, then boost with the floating AKULA bubble."
        ivGameIcon.setImageResource(R.drawable.ic_game_placeholder)
        btnLaunch.isEnabled = false
    }

    private fun showCredits() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_credit, null)
        val dialog = MaterialAlertDialogBuilder(this).setView(view).create()
        view.findViewById<View>(R.id.btnCreditClose).setOnClickListener { dialog.dismiss() }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val width = minOf(
                (resources.displayMetrics.widthPixels * 0.46f).toInt(),
                Ui.dp(this, 430)
            ).coerceAtLeast(Ui.dp(this, 300))
            dialog.window?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
    }

    private fun showAppPicker() {
        AppPickerDialog.show(
            this,
            games.map { it.packageName }.toSet()
        ) { game ->
            if (games.none { it.packageName == game.packageName }) {
                games.add(game)
                repository.save(games)
                adapter.submit(games, game.packageName)
                toast("${game.name} added")
            }
            selectGame(game)
        }
    }

    private fun confirmRemoveGame(game: Game) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Remove ${game.name}?")
            .setMessage("This only removes it from your AKULA GM library. The app stays installed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ ->
                games.removeAll { it.packageName == game.packageName }
                repository.save(games)
                val next = games.firstOrNull()
                adapter.submit(games, next?.packageName)
                if (next != null) selectGame(next) else clearInfo()
            }
            .show()
    }

    private fun launchSelected() {
        val game = selectedGame ?: return
        if (!isInstalled(game.packageName)) {
            toast("${game.name} is not installed")
            return
        }
        if (Settings.canDrawOverlays(this)) {
            doLaunch(game, withOverlay = true)
        } else {
            pendingGame = game
            toast("Allow display over other apps for the floating bubble")
            runCatching {
                overlayPermissionLauncher.launch(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }.onFailure {
                pendingGame = null
                toast("Open settings and allow display over other apps")
            }
        }
    }

    private fun doLaunch(game: Game, withOverlay: Boolean) {
        val launchIntent = packageManager.getLaunchIntentForPackage(game.packageName)
        if (launchIntent == null) {
            toast("Cannot launch ${game.name}")
            return
        }

        if (withOverlay) {
            runCatching {
                val serviceIntent = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_PACKAGE, game.packageName)
                ContextCompat.startForegroundService(this, serviceIntent)
            }.onFailure {
                toast("Overlay could not start: ${it.message}")
            }
        }

        runCatching {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        }.onFailure {
            toast("Cannot launch ${game.name}")
            return
        }

        handler.postDelayed({ moveTaskToBack(true) }, 650)
    }

    private fun connectShizuku() {
        if (!ShizukuManager.isBinderAlive()) {
            if (ShizukuManager.isInstalled(this)) {
                toast("Start Shizuku, then return and tap Connect")
                ShizukuManager.openShizuku(this)
            } else {
                toast("Install Shizuku to unlock boost features")
                ShizukuManager.openDownloadPage(this)
            }
            return
        }
        if (!ShizukuManager.hasPermission()) {
            if (!ShizukuManager.requestPermission()) {
                toast("Open Shizuku and allow AKULA GM")
            }
        } else {
            toast("Shizuku already connected")
        }
        updateShizukuUi()
    }

    private fun updateShizukuUi() {
        if (isDestroyed || isFinishing) return

        val granted = ShizukuManager.hasPermission()
        val alive = ShizukuManager.isBinderAlive()
        val installed = ShizukuManager.isInstalled(this)

        val state = when {
            granted -> getString(R.string.connected)
            alive -> getString(R.string.permission_needed)
            installed -> getString(R.string.not_connected)
            else -> getString(R.string.shizuku_missing)
        }
        val colorRes = when {
            granted -> R.color.green_500
            alive -> R.color.yellow_500
            else -> R.color.red_500
        }
        tvShizukuState.text = state
        tvShizukuState.setTextColor(ContextCompat.getColor(this, colorRes))
        tvShizukuDot.setTextColor(ContextCompat.getColor(this, colorRes))
        btnConnect.text = when {
            granted -> "CONNECTED"
            alive -> "ALLOW"
            else -> getString(R.string.connect_now)
        }

        if (granted) {
            hideNotice()
        } else if (!noticeShown) {
            noticeShown = true
            showNotice()
        }
    }

    private fun showNotice() {
        val banner = findViewById<View>(R.id.noticeBanner)
        if (banner.visibility == View.VISIBLE) return
        banner.visibility = View.VISIBLE
        banner.translationY = -Ui.dp(this, 44).toFloat()
        banner.alpha = 0f
        banner.animate().translationY(0f).alpha(1f).setDuration(260).start()
        handler.removeCallbacks(hideNoticeRunnable)
        handler.postDelayed(hideNoticeRunnable, 8000)
    }

    private fun hideNotice() {
        val banner = findViewById<View>(R.id.noticeBanner)
        if (banner.visibility != View.VISIBLE) return
        banner.animate().translationY(-Ui.dp(this, 44).toFloat()).alpha(0f).setDuration(220)
            .withEndAction { banner.visibility = View.GONE }
            .start()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun isInstalled(packageName: String): Boolean =
        runCatching { packageManager.getPackageInfo(packageName, 0) }.isSuccess

    private fun formatSize(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024.0) {
            String.format(Locale.US, "%.2f GB", mb / 1024.0)
        } else {
            String.format(Locale.US, "%.1f MB", mb)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (AppCloseBus.listener != null) AppCloseBus.listener = null
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionListener) }
        runCatching { Shizuku.removeBinderReceivedListener(binderReceivedListener) }
        runCatching { Shizuku.removeBinderDeadListener(binderDeadListener) }
    }
}
