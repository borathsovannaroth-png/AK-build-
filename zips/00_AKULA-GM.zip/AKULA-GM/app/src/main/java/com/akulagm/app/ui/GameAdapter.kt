package com.akulagm.app.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.akulagm.app.R
import com.akulagm.app.data.Game
import com.google.android.material.card.MaterialCardView

class GameAdapter(
    private val context: Context,
    private val onSelect: (Game) -> Unit,
    private val onLongPress: (Game) -> Unit
) : RecyclerView.Adapter<GameAdapter.Holder>() {

    private val items = mutableListOf<Game>()
    private var selectedPackage: String? = null

    fun submit(games: List<Game>, selected: String?) {
        items.clear()
        items.addAll(games)
        selectedPackage = selected
        notifyDataSetChanged()
    }

    fun setSelected(packageName: String) {
        selectedPackage = packageName
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val game = items[position]
        val isSelected = game.packageName == selectedPackage

        holder.name.text = game.name
        holder.packageName.text = game.packageName
        holder.icon.setImageDrawable(loadIcon(game.packageName))
        holder.mark.visibility = if (isSelected) View.VISIBLE else View.GONE

        holder.card.strokeColor = if (isSelected) 0xFFFF3B5C.toInt() else 0x33FFFFFF
        holder.card.strokeWidth = Ui.dp(context, if (isSelected) 2 else 1)
        holder.card.setCardBackgroundColor(if (isSelected) 0xFF2A0E18.toInt() else 0x26122247)
        holder.name.setTextColor(if (isSelected) 0xFFFFD7DE.toInt() else 0xFFEAF2FF.toInt())

        holder.itemView.setOnClickListener { onSelect(game) }
        holder.itemView.setOnLongClickListener {
            onLongPress(game)
            true
        }
    }

    private fun loadIcon(packageName: String) = try {
        context.packageManager.getApplicationIcon(packageName)
    } catch (t: Throwable) {
        ContextCompat.getDrawable(context, R.drawable.ic_game_placeholder)!!
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.gameCard)
        val icon: ImageView = view.findViewById(R.id.ivGameIcon)
        val name: TextView = view.findViewById(R.id.tvGameName)
        val packageName: TextView = view.findViewById(R.id.tvGamePkg)
        val mark: TextView = view.findViewById(R.id.tvSelectedMark)
    }
}
