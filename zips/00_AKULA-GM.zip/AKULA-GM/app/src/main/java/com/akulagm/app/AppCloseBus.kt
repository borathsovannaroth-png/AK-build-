package com.akulagm.app

import android.os.Handler
import android.os.Looper

object AppCloseBus {
    @Volatile
    var listener: (() -> Unit)? = null

    fun notifyClose() {
        val current = listener ?: return
        Handler(Looper.getMainLooper()).post { current() }
    }
}
