package com.akulagm.app.overlay

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.akulagm.app.AppCloseBus
import com.akulagm.app.MainActivity
import com.akulagm.app.R
import com.akulagm.app.data.GameRepository
import com.akulagm.app.shizuku.ShizukuManager
import com.akulagm.app.stats.FpsReader
import com.akulagm.app.stats.StatsMonitor
import com.akulagm.app.ui.Ui
import java.util.concurrent.Executors

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var stats: StatsMonitor
    private lateinit var repository: GameRepository
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val fpsReader = FpsReader()

    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bubbleSizePx = 0

    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var scrimView: View? = null
    private var confirmView: View? = null
    private var panelOpen = false
    private var panelWidth = 0
    private var panelHeight = 0

    private var gamePackage: String? = null

    private var ramValue: TextView? = null
    private var ramSub: TextView? = null
    private var fpsValue: TextView? = null
    private var fpsSub: TextView? = null
    private var tempValue: TextView? = null
    private var tempSub: TextView? = null

    private var ramCard: StatCard? = null
    private var fpsCard: StatCard? = null
    private var tempCard: StatCard? = null

    private val statusViews = mutableMapOf<String, TextView>()
    private val toggles = mutableMapOf<String, Toggle>()
    private val toggleState = mutableMapOf<String, Boolean>()

    private var optimizingGame = false
    private var optimizingAkula = false
    private var backgroundCleared = false
    private var backgroundPartial = false
    private var powerSave = false
    private var fullPerf = false
    private var heatReducer = false

    private var currentFps: Int? = null
    private var fpsBusy = false
    private var fpsTicker = 0

    private data class StatCard(val view: View, val drawable: GradientDrawable, var color: Int)
    private data class Toggle(val view: TextView, val accent: Int)

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        stats = StatsMonitor(this)
        repository = GameRepository(this)
        createChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            closeEverything()
            return START_NOT_STICKY
        }

        val requested = intent?.getStringExtra(EXTRA_PACKAGE) ?: repository.selectedPackage()
        if (requested != gamePackage) {
            gamePackage = requested
            fpsReader.reset()
        }

        startForegroundNow()
        showBubble()
        return START_STICKY
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "AKULA GM floating overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the game-space bubble and boost panel alive"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun startForegroundNow() {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_akula)
            .setContentTitle("AKULA GM overlay")
            .setContentText("Tap the bubble for boost controls")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Stop overlay", stopIntent)
            .build()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        if (bubbleView != null) return

        val size = Ui.dp(this, 58)
        bubbleSizePx = size

        val container = FrameLayout(this).apply {
            contentDescription = "AKULA GM floating bubble"
            alpha = 0.95f
        }
        val background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                0xFF8B5CF6.toInt(),
                0xFF3B1E7A.toInt(),
                0xFF07030F.toInt()
            )
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(Ui.dp(this@OverlayService, 1), 0x88FFFFFF.toInt())
        }
        container.background = background

        val ring = View(this).apply {
            this.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(
                    Ui.dp(this@OverlayService, 1),
                    0x553D7BFF
                )
            }
        }
        container.addView(
            ring,
            FrameLayout.LayoutParams(
                size - Ui.dp(this, 10),
                size - Ui.dp(this, 10),
                Gravity.CENTER
            )
        )

        container.addView(
            ImageView(this).apply { setImageResource(R.drawable.ic_akula_logo) },
            FrameLayout.LayoutParams(
                Ui.dp(this, 32),
                Ui.dp(this, 32),
                Gravity.CENTER
            )
        )

        val metrics = resources.displayMetrics
        val params = WindowManager.LayoutParams(
            size,
            size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = metrics.widthPixels - size - Ui.dp(this@OverlayService, 14)
            y = (metrics.heightPixels * 0.42f).toInt()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        try {
            windowManager.addView(container, params)
        } catch (t: Throwable) {
            toast("Overlay permission is required")
            stopSelf()
            return
        }

        bubbleView = container
        bubbleParams = params
        attachBubbleTouch(container, params)

        container.scaleX = 0.3f
        container.scaleY = 0.3f
        container.alpha = 0f
        container.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(0.95f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachBubbleTouch(view: View, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    val threshold = (ViewConfiguration.get(this).scaledTouchSlop * touchSensitivity())
                        .toInt()
                        .coerceAtLeast(2)
                    if (kotlin.math.abs(dx) > threshold || kotlin.math.abs(dy) > threshold) {
                        moved = true
                    }
                    if (moved) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        clampBubble(params)
                        runCatching { windowManager.updateViewLayout(v, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (!moved) {
                        togglePanel()
                    } else {
                        snapToEdge(params)
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun touchSensitivity(): Float {
        val value = getSharedPreferences(OVERLAY_PREFS, MODE_PRIVATE)
            .getInt(KEY_TOUCH, 60)
            .coerceIn(0, 100)
        return 1.55f - (value / 100f) * 1.15f
    }

    private fun clampBubble(params: WindowManager.LayoutParams) {
        val metrics = resources.displayMetrics
        params.x = params.x.coerceIn(
            -Ui.dp(this, 8),
            metrics.widthPixels - bubbleSizePx + Ui.dp(this, 8)
        )
        params.y = params.y.coerceIn(
            Ui.dp(this, 24),
            metrics.heightPixels - bubbleSizePx - Ui.dp(this, 24)
        )
    }

    private fun snapToEdge(params: WindowManager.LayoutParams) {
        val metrics = resources.displayMetrics
        val margin = Ui.dp(this, 14)
        val target = if (params.x + bubbleSizePx / 2 < metrics.widthPixels / 2) {
            margin
        } else {
            metrics.widthPixels - bubbleSizePx - margin
        }
        ValueAnimator.ofInt(params.x, target).apply {
            duration = 180
            addUpdateListener { animator ->
                params.x = animator.animatedValue as Int
                bubbleView?.let { view ->
                    runCatching { windowManager.updateViewLayout(view, params) }
                }
            }
            start()
        }
    }

    private fun togglePanel() {
        if (panelOpen) collapsePanel() else expandPanel()
    }

    private fun expandPanel() {
        if (panelOpen) return
        panelOpen = true
        bubbleView?.visibility = View.GONE

        val scrim = View(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { collapsePanel() }
        }
        val scrimParams = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        try {
            windowManager.addView(scrim, scrimParams)
            scrimView = scrim
        } catch (t: Throwable) {
            panelOpen = false
            bubbleView?.visibility = View.VISIBLE
            return
        }
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(170).start()

        val themed = ContextThemeWrapper(this, R.style.Theme_AkulaGM)
        val view = LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null)
        bindPanel(view)

        val metrics = resources.displayMetrics
        panelWidth = minOf((metrics.widthPixels * 0.90f).toInt(), Ui.dp(this, 760))
        panelHeight = minOf((metrics.heightPixels * 0.88f).toInt(), Ui.dp(this, 620))

        val params = WindowManager.LayoutParams(
            panelWidth,
            panelHeight,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        try {
            windowManager.addView(view, params)
        } catch (t: Throwable) {
            runCatching { windowManager.removeView(scrim) }
            scrimView = null
            panelOpen = false
            bubbleView?.visibility = View.VISIBLE
            return
        }

        panelView = view
        panelParams = params
        view.alpha = 0f
        view.scaleX = 0.88f
        view.scaleY = 0.88f
        view.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .start()

        startStatsLoop()
    }

    private fun collapsePanel() {
        if (!panelOpen) return
        panelOpen = false
        stopStatsLoop()

        val view = panelView
        val scrim = scrimView
        panelView = null
        panelParams = null
        scrimView = null
        ramValue = null
        fpsValue = null
        tempValue = null

        view?.animate()
            ?.alpha(0f)
            ?.scaleX(0.9f)
            ?.scaleY(0.9f)
            ?.setDuration(150)
            ?.withEndAction { runCatching { windowManager.removeView(view) } }
            ?.start()

        scrim?.animate()
            ?.alpha(0f)
            ?.setDuration(150)
            ?.withEndAction { runCatching { windowManager.removeView(scrim) } }
            ?.start()

        bubbleView?.visibility = View.VISIBLE
        bubbleView?.scaleX = 0.8f
        bubbleView?.scaleY = 0.8f
        bubbleView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(180)?.start()
    }

    private fun bindPanel(root: View) {
        root.findViewById<TextView>(R.id.tvOverlayTitle).apply {
            setShadowLayer(Ui.dp(this@OverlayService, 9).toFloat(), 0f, 0f, 0xAA3D7BFF.toInt())
        }

        ramValue = root.findViewById(R.id.tvRamValue)
        ramSub = root.findViewById(R.id.tvRamSub)
        fpsValue = root.findViewById(R.id.tvFpsValue)
        fpsSub = root.findViewById(R.id.tvFpsSub)
        tempValue = root.findViewById(R.id.tvTempValue)
        tempSub = root.findViewById(R.id.tvTempSub)

        ramCard = setupStatCard(root.findViewById(R.id.cardRam), 0x333D7BFF)
        fpsCard = setupStatCard(root.findViewById(R.id.cardFps), 0x331B3370)
        tempCard = setupStatCard(root.findViewById(R.id.cardTemp), 0x404DD8FF)

        root.findViewById<View>(R.id.btnCollapse).setOnClickListener { collapsePanel() }
        root.findViewById<View>(R.id.btnClosePanel).setOnClickListener { showCloseConfirm() }
        root.findViewById<View>(R.id.btnRefreshStats).setOnClickListener {
            refreshStats(forceFps = true)
        }
        root.findViewById<View>(R.id.btnGoShizuku).setOnClickListener {
            ShizukuManager.openShizuku(this)
        }

        buildFunctions(root.findViewById(R.id.functionsContainer))
        buildStatus(root.findViewById(R.id.statusContainer))

        refreshStats(forceFps = true)
    }

    private fun setupStatCard(view: View, fill: Int): StatCard {
        val drawable = Ui.glass(this, fill, 0x44FFFFFF, 18f)
        view.background = drawable
        return StatCard(view, drawable, fill)
    }

    private fun tint(card: StatCard?, target: Int) {
        if (card == null || card.color == target) return
        ValueAnimator.ofObject(ArgbEvaluator(), card.color, target).apply {
            duration = 380
            addUpdateListener { animator ->
                card.drawable.setColor(animator.animatedValue as Int)
                card.view.invalidate()
            }
            start()
        }
        card.color = target
    }

    private fun buildFunctions(container: LinearLayout) {
        container.removeAllViews()

        addFunctionRow(
            container,
            "Optimize game",
            "Game mode → performance (Shizuku)",
            actionPill("RUN", 0xFF7FA8FF.toInt()) { optimizeGame() }
        )
        addFunctionRow(
            container,
            "Optimize AKULA GM",
            "Trim our own caches & memory",
            actionPill("ACT", 0xFF8B5CF6.toInt()) { optimizeAkula() }
        )
        addFunctionRow(
            container,
            "Clear cache",
            "System cache trim + AKULA cache",
            actionPill("RUN", 0xFF7FA8FF.toInt()) { clearCache() }
        )
        addFunctionRow(
            container,
            "Clear RAM",
            "Kill background processes",
            actionPill("RUN", 0xFF7FA8FF.toInt()) { clearRam() }
        )
        addFunctionRow(
            container,
            "Power save",
            "Battery game mode + slower polling",
            togglePill("power", powerSave, 0xFF2EE6A8.toInt()) { setPowerSave(it) }
        )
        addFunctionRow(
            container,
            "Gaming full performance",
            "Performance game mode + full polling",
            togglePill("perf", fullPerf, 0xFFFFC94D.toInt()) { setFullPerformance(it) }
        )
        addFunctionRow(
            container,
            "Heat reducer",
            "Lower overlay load + battery mode",
            togglePill("heat", heatReducer, 0xFF4DD8FF.toInt()) { setHeatReducer(it) }
        )
        addFunctionRow(
            container,
            "Clear background app",
            "Except AKULA GM + Shizuku",
            actionPill("ACT", 0xFFFF9A3D.toInt()) { clearBackground() }
        )
        addTouchRow(container)
    }

    private fun addFunctionRow(
        container: LinearLayout,
        title: String,
        subtitle: String,
        control: View
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(this@OverlayService, 7), 0, Ui.dp(this@OverlayService, 7))
        }

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFEAF2FF.toInt())
            textSize = 13f
        })
        if (subtitle.isNotEmpty()) {
            texts.addView(TextView(this).apply {
                text = subtitle
                setTextColor(0xFF8FA3C8.toInt())
                textSize = 9f
            })
        }

        row.addView(
            texts,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(control)
        container.addView(row)
        container.addView(divider())
    }

    private fun addTouchRow(container: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(this@OverlayService, 7), 0, Ui.dp(this@OverlayService, 7))
        }

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = "Fix touch"
            setTextColor(0xFFEAF2FF.toInt())
            textSize = 13f
        })
        texts.addView(TextView(this).apply {
            text = "Min — max response"
            setTextColor(0xFF8FA3C8.toInt())
            textSize = 9f
        })
        row.addView(
            texts,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        val prefs = getSharedPreferences(OVERLAY_PREFS, MODE_PRIVATE)
        val valueView = TextView(this).apply {
            setTextColor(0xFF7FA8FF.toInt())
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
        }
        val seekBar = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt(KEY_TOUCH, 60)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(this@OverlayService, 148), Ui.dp(this@OverlayService, 36))
        }
        valueView.text = "${seekBar.progress}%"
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                valueView.text = "$progress%"
                prefs.edit().putInt(KEY_TOUCH, progress).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(valueView)
            addView(seekBar)
        }
        row.addView(box)
        container.addView(row)
        container.addView(divider())
    }

    private fun actionPill(label: String, accent: Int, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(accent)
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(
                Ui.dp(this@OverlayService, 14),
                Ui.dp(this@OverlayService, 7),
                Ui.dp(this@OverlayService, 14),
                Ui.dp(this@OverlayService, 7)
            )
            background = Ui.pill(this@OverlayService, 0x22122247, 0x44FFFFFF)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun togglePill(
        key: String,
        initial: Boolean,
        accent: Int,
        onChange: (Boolean) -> Unit
    ): TextView {
        toggleState[key] = initial
        val view = TextView(this).apply {
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(
                Ui.dp(this@OverlayService, 16),
                Ui.dp(this@OverlayService, 7),
                Ui.dp(this@OverlayService, 16),
                Ui.dp(this@OverlayService, 7)
            )
            isClickable = true
            isFocusable = true
        }
        toggles[key] = Toggle(view, accent)
        view.setOnClickListener {
            val next = !(toggleState[key] ?: false)
            toggleState[key] = next
            renderToggle(key)
            onChange(next)
        }
        renderToggle(key)
        return view
    }

    private fun renderToggle(key: String) {
        val toggle = toggles[key] ?: return
        val on = toggleState[key] == true
        toggle.view.text = if (on) "ON" else "OFF"
        toggle.view.setTextColor(if (on) toggle.accent else 0xFF8FA3C8.toInt())
        val fill = if (on) {
            (toggle.accent and 0x00FFFFFF) or 0x33000000
        } else {
            0x22122247
        }
        val stroke = if (on) {
            (toggle.accent and 0x00FFFFFF) or 0x88000000.toInt()
        } else {
            0x44FFFFFF
        }
        toggle.view.background = Ui.pill(this, fill, stroke)
    }

    private fun setToggle(key: String, on: Boolean) {
        toggleState[key] = on
        renderToggle(key)
    }

    private fun divider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            Ui.dp(this@OverlayService, 1)
        )
        setBackgroundColor(0x14FFFFFF)
    }

    private fun buildStatus(container: LinearLayout) {
        container.removeAllViews()
        statusViews.clear()

        addStatusRow(container, "Free RAM", "ram")
        addStatusRow(container, "Optimize game yet?", "game")
        addStatusRow(container, "Optimize AKULA GM yet?", "akula")
        addStatusRow(container, "Background clear?", "bg")
        addStatusRow(container, "Power saving mode?", "power")
        addStatusRow(container, "Heat reducer working?", "heat")
        addStatusRow(container, "Shizuku status", "shizuku")
    }

    private fun addStatusRow(container: LinearLayout, label: String, key: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(this@OverlayService, 5), 0, Ui.dp(this@OverlayService, 5))
        }
        row.addView(
            TextView(this).apply {
                text = label
                setTextColor(0xFF8FA3C8.toInt())
                textSize = 10f
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val value = TextView(this).apply {
            text = "—"
            setTextColor(0xFFEAF2FF.toInt())
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
        }
        row.addView(value)
        container.addView(row)
        container.addView(divider())
        statusViews[key] = value
    }

    private fun setStatus(key: String, text: String, color: Int) {
        statusViews[key]?.apply {
            this.text = text
            setTextColor(color)
        }
    }

    private val statsRunnable = object : Runnable {
        override fun run() {
            if (!panelOpen) return
            refreshStats()
            val interval = if (heatReducer || powerSave) 3000L else 1200L
            handler.postDelayed(this, interval)
        }
    }

    private fun startStatsLoop() {
        handler.removeCallbacks(statsRunnable)
        handler.post(statsRunnable)
    }

    private fun stopStatsLoop() {
        handler.removeCallbacks(statsRunnable)
    }

    private fun refreshStats(forceFps: Boolean = false) {
        if (!panelOpen) return

        val ram = stats.ram()
        ramValue?.apply {
            text = "${ram.availableMb}/${ram.totalMb}"
            setTextColor(0xFF7FA8FF.toInt())
        }
        ramSub?.text = "MB free / total"
        setStatus("ram", "${ram.availableMb} / ${ram.totalMb} MB", 0xFFEAF2FF.toInt())
        tint(ramCard, 0x333D7BFF)

        val temperature = stats.temperatureC()
        tempValue?.apply {
            text = "${temperature.toInt()}°C"
            setTextColor(if (temperature <= 40f) 0xFF4DD8FF.toInt() else 0xFFFF9A3D.toInt())
        }
        tempSub?.text = if (temperature >= 45f) "hot — cool down" else "sensor"
        tint(tempCard, if (temperature <= 40f) 0x404DD8FF else 0x40FF9A3D)

        val shizukuOk = ShizukuManager.hasPermission()
        setStatus(
            "game",
            if (optimizingGame) "Yes" else "No",
            if (optimizingGame) 0xFF2EE6A8.toInt() else 0xFF8FA3C8.toInt()
        )
        setStatus(
            "akula",
            if (optimizingAkula) "Yes" else "No",
            if (optimizingAkula) 0xFF2EE6A8.toInt() else 0xFF8FA3C8.toInt()
        )
        val clearText = when {
            backgroundCleared -> "Yes"
            backgroundPartial -> "Still have some"
            else -> "Not yet"
        }
        val clearColor = when {
            backgroundCleared -> 0xFF2EE6A8.toInt()
            backgroundPartial -> 0xFFFFC94D.toInt()
            else -> 0xFF8FA3C8.toInt()
        }
        setStatus("bg", clearText, clearColor)
        setStatus(
            "power",
            if (toggleState["power"] == true) "Yes" else "No",
            if (toggleState["power"] == true) 0xFF2EE6A8.toInt() else 0xFF8FA3C8.toInt()
        )
        setStatus(
            "heat",
            if (toggleState["heat"] == true) "Yes" else "No",
            if (toggleState["heat"] == true) 0xFF2EE6A8.toInt() else 0xFF8FA3C8.toInt()
        )
        setStatus(
            "shizuku",
            when {
                shizukuOk -> "Connected"
                ShizukuManager.isBinderAlive() -> "Permission needed"
                else -> "Not yet"
            },
            if (shizukuOk) 0xFF2EE6A8.toInt() else 0xFFFF3B5C.toInt()
        )

        updateFps(forceFps)
    }

    private fun updateFps(force: Boolean) {
        if (!ShizukuManager.hasPermission()) {
            currentFps = null
            applyFpsUi()
            return
        }
        if (fpsBusy) return
        if (!force) {
            fpsTicker++
            if (fpsTicker % 2 != 0) {
                applyFpsUi()
                return
            }
        }
        fpsBusy = true
        val packageName = gamePackage
        io.execute {
            val value = fpsReader.read(packageName)
            handler.post {
                fpsBusy = false
                currentFps = value
                applyFpsUi()
            }
        }
    }

    private fun applyFpsUi() {
        val value = currentFps
        if (value == null) {
            fpsValue?.apply {
                text = "—"
                setTextColor(0xFF8FA3C8.toInt())
            }
            fpsSub?.text = if (ShizukuManager.hasPermission()) "no layer data" else "needs Shizuku"
            tint(fpsCard, 0x331B3370)
            return
        }
        fpsValue?.apply {
            text = value.toString()
            setTextColor(
                when {
                    value < 15 -> 0xFFFF3B5C.toInt()
                    value < 35 -> 0xFFFFC94D.toInt()
                    else -> 0xFF2EE6A8.toInt()
                }
            )
        }
        fpsSub?.text = "realtime"
        tint(
            fpsCard,
            when {
                value < 15 -> 0x40FF3B5C
                value < 35 -> 0x40FFC94D
                else -> 0x402EE6A8
            }
        )
    }

    private fun shell(command: String): Pair<Boolean, String> {
        val output = ShizukuManager.exec("$command 2>&1")
            ?: return false to "Shizuku not connected"
        val lower = output.lowercase()
        val failed = lower.contains("error") ||
            lower.contains("unknown") ||
            lower.contains("exception") ||
            lower.contains("not found") ||
            lower.contains("permission denial") ||
            lower.contains("failed")
        return (!failed) to output.trim()
    }

    private fun optimizeGame() {
        val packageName = gamePackage
        if (packageName == null) {
            toast("Launch a game first")
            return
        }
        if (!ShizukuManager.hasPermission()) {
            toast("Connect Shizuku first")
            return
        }
        toast("Optimizing game…")
        io.execute {
            var result = shell("cmd game set --user 0 --mode performance $packageName")
            if (!result.first) {
                result = shell("cmd game set --mode performance $packageName")
            }
            val ok = result.first
            handler.post {
                optimizingGame = ok
                toast(if (ok) "Game mode: performance" else "Could not set game mode")
                refreshStats()
            }
        }
    }

    private fun optimizeAkula() {
        io.execute {
            runCatching {
                cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                codeCacheDir.listFiles()?.forEach { it.deleteRecursively() }
                System.gc()
            }
            if (ShizukuManager.hasPermission()) {
                shell("am send-trim-memory $packageName RUNNING_CRITICAL")
            }
            handler.post {
                optimizingAkula = true
                toast("AKULA GM optimized")
                refreshStats()
            }
        }
    }

    private fun clearCache() {
        io.execute {
            runCatching {
                cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                codeCacheDir.listFiles()?.forEach { it.deleteRecursively() }
            }
            val systemTrim = if (ShizukuManager.hasPermission()) {
                shell("pm trim-caches 999G").first
            } else {
                false
            }
            handler.post {
                toast(
                    if (systemTrim) "Caches trimmed"
                    else "AKULA cache cleared (Shizuku needed for system cache)"
                )
                refreshStats()
            }
        }
    }

    private fun clearRam() {
        if (!ShizukuManager.hasPermission()) {
            toast("Connect Shizuku first")
            return
        }
        toast("Clearing background RAM…")
        io.execute {
            val result = shell("am kill-all")
            handler.post {
                backgroundCleared = result.first
                backgroundPartial = !result.first
                toast(if (result.first) "Background RAM cleared" else "Could not clear RAM")
                refreshStats()
            }
        }
    }

    private fun clearBackground() {
        if (!ShizukuManager.hasPermission()) {
            toast("Connect Shizuku first")
            return
        }
        toast("Clearing background apps…")
        io.execute {
            val result = shell("am kill-all")
            handler.post {
                backgroundCleared = result.first
                backgroundPartial = !result.first
                toast(
                    if (result.first) "Background cleared (AKULA & Shizuku kept)"
                    else "Some apps are still running"
                )
                refreshStats()
            }
        }
    }

    private fun setPowerSave(on: Boolean) {
        powerSave = on
        setToggle("power", on)
        if (on) {
            fullPerf = false
            setToggle("perf", false)
        }
        val packageName = gamePackage
        if (ShizukuManager.hasPermission() && packageName != null) {
            io.execute {
                shell(
                    "cmd game set --user 0 --mode ${if (on) "battery" else "standard"} $packageName"
                )
            }
        }
        toast(if (on) "Power save on" else "Power save off")
        refreshStats()
    }

    private fun setFullPerformance(on: Boolean) {
        fullPerf = on
        setToggle("perf", on)
        if (on) {
            powerSave = false
            setToggle("power", false)
        }
        val packageName = gamePackage
        if (ShizukuManager.hasPermission() && packageName != null) {
            io.execute {
                shell(
                    "cmd game set --user 0 --mode ${if (on) "performance" else "standard"} $packageName"
                )
            }
        }
        toast(if (on) "Full performance on" else "Full performance off")
        refreshStats()
    }

    private fun setHeatReducer(on: Boolean) {
        heatReducer = on
        setToggle("heat", on)
        val packageName = gamePackage
        if (on && !fullPerf && ShizukuManager.hasPermission() && packageName != null) {
            io.execute {
                shell("cmd game set --user 0 --mode battery $packageName")
            }
        }
        toast(if (on) "Heat reducer on" else "Heat reducer off")
        refreshStats()
    }

    private fun showCloseConfirm() {
        if (confirmView != null) return

        val wrapper = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            isClickable = true
            setOnClickListener { removeConfirm() }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.glass(this@OverlayService, 0xF20A1530.toInt(), 0x55FFFFFF, 22f)
            setPadding(
                Ui.dp(this@OverlayService, 22),
                Ui.dp(this@OverlayService, 22),
                Ui.dp(this@OverlayService, 22),
                Ui.dp(this@OverlayService, 18)
            )
            isClickable = true
        }

        card.addView(TextView(this).apply {
            text = "Close AKULA GM?"
            setTextColor(0xFFEAF2FF.toInt())
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
        })
        card.addView(TextView(this).apply {
            text = "Are you sure to close the window?\nThe game you launched will keep running."
            setTextColor(0xFF8FA3C8.toInt())
            textSize = 11f
            setPadding(0, Ui.dp(this@OverlayService, 8), 0, Ui.dp(this@OverlayService, 16))
        })

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }

        val no = TextView(this).apply {
            text = "NO"
            setTextColor(0xFF2EE6A8.toInt())
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(
                Ui.dp(this@OverlayService, 20),
                Ui.dp(this@OverlayService, 9),
                Ui.dp(this@OverlayService, 20),
                Ui.dp(this@OverlayService, 9)
            )
            background = Ui.pill(this@OverlayService, 0x222EE6A8, 0x882EE6A8.toInt())
            isClickable = true
            setOnClickListener { removeConfirm() }
        }

        val yes = TextView(this).apply {
            text = "YES"
            setTextColor(0xFFFF3B5C.toInt())
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(
                Ui.dp(this@OverlayService, 20),
                Ui.dp(this@OverlayService, 9),
                Ui.dp(this@OverlayService, 20),
                Ui.dp(this@OverlayService, 9)
            )
            background = Ui.pill(this@OverlayService, 0x22FF3B5C, 0x88FF3B5C.toInt())
            isClickable = true
            setOnClickListener {
                removeConfirm()
                closeEverything()
            }
        }

        buttons.addView(no)
        buttons.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(this@OverlayService, 10), 1)
        })
        buttons.addView(yes)
        card.addView(buttons)

        wrapper.addView(
            card,
            FrameLayout.LayoutParams(
                minOf(
                    Ui.dp(this, 360),
                    (resources.displayMetrics.widthPixels * 0.8f).toInt()
                ),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager.addView(wrapper, params)
        } catch (t: Throwable) {
            return
        }
        confirmView = wrapper
        wrapper.alpha = 0f
        wrapper.animate().alpha(1f).setDuration(140).start()
    }

    private fun removeConfirm() {
        val view = confirmView ?: return
        confirmView = null
        runCatching { windowManager.removeView(view) }
    }

    private fun closeEverything() {
        handler.removeCallbacksAndMessages(null)
        stopStatsLoop()
        removeConfirm()
        removePanelImmediate()
        removeBubble()
        fpsReader.reset()
        io.shutdownNow()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        AppCloseBus.notifyClose()
        stopSelf()
    }

    private fun removePanelImmediate() {
        panelOpen = false
        panelView?.let { runCatching { windowManager.removeView(it) } }
        scrimView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelParams = null
        scrimView = null
        ramValue = null
        fpsValue = null
        tempValue = null
    }

    private fun removeBubble() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
        bubbleParams = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bubbleParams?.let { params ->
            clampBubble(params)
            bubbleView?.let { view ->
                runCatching { windowManager.updateViewLayout(view, params) }
            }
        }
        if (panelOpen) {
            val metrics = resources.displayMetrics
            panelWidth = minOf((metrics.widthPixels * 0.90f).toInt(), Ui.dp(this, 760))
            panelHeight = minOf((metrics.heightPixels * 0.88f).toInt(), Ui.dp(this, 620))
            panelParams?.let { params ->
                params.width = panelWidth
                params.height = panelHeight
                panelView?.let { view ->
                    runCatching { windowManager.updateViewLayout(view, params) }
                }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopStatsLoop()
        removeConfirm()
        removePanelImmediate()
        removeBubble()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun toast(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        const val EXTRA_PACKAGE = "extra_package"
        const val ACTION_STOP = "com.akulagm.app.action.STOP_OVERLAY"

        private const val CHANNEL_ID = "akula_overlay"
        private const val NOTIFICATION_ID = 7311
        private const val OVERLAY_PREFS = "akula_overlay"
        private const val KEY_TOUCH = "touch"
    }
}
