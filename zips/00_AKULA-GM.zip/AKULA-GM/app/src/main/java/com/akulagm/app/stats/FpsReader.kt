package com.akulagm.app.stats

import com.akulagm.app.shizuku.ShizukuManager

/**
 * Reads real presented-frame timing for the foreground game layer through
 * SurfaceFlinger (via Shizuku, shell uid). Falls back to null when the layer
 * or SurfaceFlinger data is unavailable.
 */
class FpsReader {

    private var cachedLayer: String? = null
    private var cachedFor: String? = null

    fun reset() {
        cachedLayer = null
        cachedFor = null
    }

    fun read(packageName: String?): Int? {
        if (!ShizukuManager.hasPermission()) return null
        if (cachedLayer == null || cachedFor != packageName) {
            cachedLayer = findLayer(packageName)
            cachedFor = packageName
        }
        val layer = cachedLayer ?: return null
        val output = ShizukuManager.exec("dumpsys SurfaceFlinger --latency ${quote(layer)}")
            ?: return null
        return parseFps(output)
    }

    private fun findLayer(packageName: String?): String? {
        val output = ShizukuManager.exec("dumpsys SurfaceFlinger --list") ?: return null
        val layers = output.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        if (layers.isEmpty()) return null

        if (packageName != null) {
            val matches = layers.filter { it.contains(packageName) }
            matches.firstOrNull { it.contains("SurfaceView", ignoreCase = true) }?.let { return it }
            matches.firstOrNull {
                !it.contains("Background", true) && !it.contains("StatusBar", true)
            }?.let { return it }
            matches.firstOrNull()?.let { return it }
        }
        return layers.firstOrNull { it.contains("SurfaceView", ignoreCase = true) }
    }

    private fun parseFps(output: String): Int? {
        val lines = output.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        if (lines.size < 5) return null

        val timestamps = ArrayList<Long>(lines.size)
        for (index in 1 until lines.size) {
            val parts = lines[index].split(' ', '\t').filter { it.isNotEmpty() }
            if (parts.size < 3) continue
            val presented = parts[1].toLongOrNull() ?: continue
            if (presented > 0L && presented != Long.MAX_VALUE) timestamps.add(presented)
        }
        if (timestamps.size < 2) return null
        val span = timestamps.last() - timestamps.first()
        if (span <= 0L) return null
        val fps = ((timestamps.size - 1).toDouble() * 1_000_000_000.0 / span).toInt()
        return fps.coerceIn(0, 240)
    }

    private fun quote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"
}
