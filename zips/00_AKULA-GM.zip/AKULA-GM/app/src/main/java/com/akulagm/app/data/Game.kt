package com.akulagm.app.data

data class Game(
    val name: String,
    val packageName: String,
    val builtIn: Boolean = false
)
