package com.akulagm.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.akulagm.app.R
import com.akulagm.app.data.Game

object AppPickerDialog {

    private data class Entry(val label: String, val packageName: String, val icon: Drawable)

    fun show(context: Context, existing: Set<String>, onPick: (Game) -> Unit) {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val entries = runCatching {
            packageManager.queryIntentActivities(launcherIntent, 0)
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    val label = info.loadLabel(packageManager)?.toString() ?: pkg
                    val icon = runCatching { info.loadIcon(packageManager) }.getOrNull()
                        ?: return@mapNotNull null
                    Entry(label, pkg, icon)
                }
                .filter { it.packageName != context.packageName && it.packageName !in existing }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
        }.getOrElse { emptyList() }

        val layout = LayoutInflater.from(context).inflate(R.layout.dialog_app_picker, null)
        val search = layout.findViewById<EditText>(R.id.etSearch)
        val list = layout.findViewById<ListView>(R.id.lvApps)
        val adapter = EntryAdapter(context, entries)
        list.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })

        val dialog = AlertDialog.Builder(context).setView(layout).create()

        list.setOnItemClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position)
            dialog.dismiss()
            onPick(Game(entry.label, entry.packageName, false))
        }

        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            val metrics = context.resources.displayMetrics
            dialog.window?.setLayout(
                (metrics.widthPixels * 0.56f).toInt().coerceAtLeast(Ui.dp(context, 320)),
                (metrics.heightPixels * 0.82f).toInt()
            )
        }
        dialog.show()
    }

    private class EntryAdapter(
        private val context: Context,
        private val all: List<Entry>
    ) : BaseAdapter() {

        private var shown: List<Entry> = all

        override fun getCount(): Int = shown.size

        override fun getItem(position: Int): Entry = shown[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(context, 6), Ui.dp(context, 8), Ui.dp(context, 6), Ui.dp(context, 8))
            }
            row.removeAllViews()

            val entry = getItem(position)

            val icon = ImageView(context).apply {
                setImageDrawable(entry.icon)
                layoutParams = LinearLayout.LayoutParams(Ui.dp(context, 38), Ui.dp(context, 38))
            }

            val label = TextView(context).apply {
                text = entry.label
                setTextColor(0xFFEAF2FF.toInt())
                textSize = 13f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(Ui.dp(context, 12), 0, 0, 0)
            }

            val packageName = TextView(context).apply {
                text = entry.packageName
                setTextColor(0xFF8FA3C8.toInt())
                textSize = 8f
                maxLines = 1
                setPadding(Ui.dp(context, 12), 0, 0, 0)
            }

            val texts = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f
                )
                addView(label)
                addView(packageName)
            }

            row.addView(icon)
            row.addView(texts)
            return row
        }

        fun filter(query: String) {
            shown = if (query.isBlank()) {
                all
            } else {
                all.filter {
                    it.label.contains(query, ignoreCase = true) ||
                        it.packageName.contains(query, ignoreCase = true)
                }
            }
            notifyDataSetChanged()
        }
    }
}
