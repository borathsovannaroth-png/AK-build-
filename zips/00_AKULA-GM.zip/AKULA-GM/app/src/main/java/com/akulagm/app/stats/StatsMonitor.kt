package com.akulagm.app.stats

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File

class StatsMonitor(private val context: Context) {

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun ram(): RamInfo {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024L * 1024L)
        val availableMb = info.availMem / (1024L * 1024L)
        return RamInfo(availableMb, totalMb)
    }

    fun temperatureC(): Float {
        readThermalZones()?.let { return it }
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            tenths / 10f
        } catch (t: Throwable) {
            0f
        }
    }

    private fun readThermalZones(): Float? {
        return try {
            val zones = File("/sys/class/thermal")
                .listFiles { file -> file.name.startsWith("thermal_zone") }
                ?: return null
            var hottest = 0f
            for (zone in zones) {
                val raw = runCatching {
                    File(zone, "temp").readText().trim().toFloat()
                }.getOrNull() ?: continue
                val celsius = if (raw > 1000f) raw / 1000f else raw
                if (celsius in 1f..120f && celsius > hottest) hottest = celsius
            }
            if (hottest > 0f) hottest else null
        } catch (t: Throwable) {
            null
        }
    }

    data class RamInfo(val availableMb: Long, val totalMb: Long)
}
