package com.akulagm.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class GameRepository(context: Context) {

    private val prefs = context.getSharedPreferences("akula_games", Context.MODE_PRIVATE)

    fun load(): MutableList<Game> {
        val raw = prefs.getString(KEY_GAMES, null)
        if (raw.isNullOrBlank()) return defaults().toMutableList()
        return try {
            val array = JSONArray(raw)
            val result = mutableListOf<Game>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val pkg = item.optString("pkg")
                if (pkg.isNotBlank()) {
                    result.add(
                        Game(
                            name = item.optString("name", pkg),
                            packageName = pkg,
                            builtIn = item.optBoolean("builtIn", false)
                        )
                    )
                }
            }
            if (result.isEmpty()) defaults().toMutableList() else result
        } catch (t: Throwable) {
            defaults().toMutableList()
        }
    }

    fun save(games: List<Game>) {
        val array = JSONArray()
        games.forEach { game ->
            array.put(
                JSONObject()
                    .put("name", game.name)
                    .put("pkg", game.packageName)
                    .put("builtIn", game.builtIn)
            )
        }
        prefs.edit().putString(KEY_GAMES, array.toString()).apply()
    }

    fun selectedPackage(): String? = prefs.getString(KEY_SELECTED, null)

    fun setSelected(packageName: String) {
        prefs.edit().putString(KEY_SELECTED, packageName).apply()
    }

    fun overlayPrefs() = prefs

    fun defaults(): List<Game> = listOf(
        Game("Mobile Legends", "com.mobile.legends", true),
        Game("Roblox", "com.roblox.client", true),
        Game("Minecraft", "com.mojang.minecraftpe", true),
        Game("BB Racing", "com.creativemobile.BBRacing", true),
        Game("Subway Surfers", "com.kiloo.subwaysurf", true)
    )

    companion object {
        private const val KEY_GAMES = "games"
        private const val KEY_SELECTED = "selected"
    }
}
