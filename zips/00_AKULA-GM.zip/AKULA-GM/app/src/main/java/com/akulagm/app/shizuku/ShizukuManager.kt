package com.akulagm.app.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

object ShizukuManager {

    const val REQUEST_CODE = 4201
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    @Volatile
    private var processMethod: Method? = null

    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (t: Throwable) {
        false
    }

    fun isBinderAlive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isBinderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    fun requestPermission(): Boolean = try {
        if (!isBinderAlive()) {
            false
        } else if (hasPermission()) {
            true
        } else {
            Shizuku.requestPermission(REQUEST_CODE)
            true
        }
    } catch (t: Throwable) {
        false
    }

    fun statusText(): String = when {
        !isBinderAlive() -> "Not connected"
        !hasPermission() -> "Permission needed"
        else -> "Connected"
    }

    fun openShizuku(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(launch) }
        } else {
            openDownloadPage(context)
        }
    }

    fun openDownloadPage(context: Context) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /**
     * Runs a shell command through the Shizuku service (shell uid).
     * Shizuku 13.x exposes the remote process helper reflectively.
     */
    fun exec(command: String): String? {
        if (!hasPermission()) return null
        var process: Process? = null
        return try {
            val method = processMethod ?: resolveProcessMethod()?.also { processMethod = it }
                ?: return null
            process = method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as? Process ?: return null
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            process.waitFor()
            output
        } catch (t: Throwable) {
            null
        } finally {
            runCatching { process?.destroy() }
        }
    }

    private fun resolveProcessMethod(): Method? = try {
        val stringArray = arrayOf<String>().javaClass
        Shizuku::class.java
            .getDeclaredMethod("newProcess", stringArray, stringArray, String::class.java)
            .apply { isAccessible = true }
    } catch (t: Throwable) {
        null
    }
}
