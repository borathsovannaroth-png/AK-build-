package com.akulagm.app.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable

object Ui {

    fun dp(context: Context, value: Number): Int =
        (value.toFloat() * context.resources.displayMetrics.density).toInt()

    fun glass(
        context: Context,
        fill: Int,
        stroke: Int,
        radiusDp: Float = 18f,
        strokeWidthDp: Float = 1f
    ): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(context, radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(context, strokeWidthDp), stroke)
    }

    fun pill(
        context: Context,
        fill: Int,
        stroke: Int,
        radiusDp: Float = 20f
    ): GradientDrawable = glass(context, fill, stroke, radiusDp)
}
