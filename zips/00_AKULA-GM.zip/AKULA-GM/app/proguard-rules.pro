# AKULA GM release rules (minify is disabled, kept for future use)
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
